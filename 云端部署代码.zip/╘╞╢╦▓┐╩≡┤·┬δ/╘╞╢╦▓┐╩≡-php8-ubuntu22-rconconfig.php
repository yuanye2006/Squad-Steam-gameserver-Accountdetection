<?php
// rconconfig.php

// RCON 服务器信息
$ip = '103.40.14.7';  // RCON 服务器 IP 地址
$port = 36912;  // RCON 服务器端口
$password = 'yuanye20060516';  // RCON 密码
$timeout = 6;  // 超时时间

// 获取 RCON 配置的函数
function getRconConfig() {
    // 使用 global 关键字将变量声明为全局
    global $ip, $port, $password, $timeout;

    // 返回关联数组包含 RCON 服务器的所有配置
    return [
        'ip' => $ip,
        'port' => $port,
        'password' => $password,
        'timeout' => $timeout
    ];
}
