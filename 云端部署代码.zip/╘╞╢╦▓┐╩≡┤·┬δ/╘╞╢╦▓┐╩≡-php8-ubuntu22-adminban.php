<?php

require_once __DIR__ . '/vendor/autoload.php';

use xPaw\SourceQuery\SourceQuery;
use xPaw\SourceQuery\Exception\SourceQueryException;

require_once 'rconconfig.php';

// 获取 RCON 配置信息
$rconConfig = getRconConfig();

// 使用 RCON 配置信息
$ip = $rconConfig['ip'];
$port = $rconConfig['port'];
$password = $rconConfig['password'];
$timeout = $rconConfig['timeout'];

$query = new SourceQuery();

$responseMessage = '';

// 检查是否提供了id、reason和time参数
if (isset($_GET['id'], $_GET['reason'], $_GET['time'])) {
    $playerId = $_GET['id'];
    $banReason = $_GET['reason'];
    $banTime = $_GET['time'];

    // 验证time参数是否符合规定格式
    if (!preg_match('/^(\d+d|\d+m|\d+y|0)$/', $banTime)) {
        $responseMessage = ['error' => '时间参数格式错误。可接受格式为0, xd, xm, xy，其中x是阿拉伯数字。'];
    } else {
        try {
            $query->Connect($ip, $port, $timeout, SourceQuery::SOURCE);
            $query->SetRconPassword($password);
            
            // 发送AdminBanById命令
            $command = sprintf('AdminBan %s %s %s', $playerId, $banTime, $banReason);
            $response = $query->Rcon($command);
            
            // 根据响应设置消息
            if (strpos($response, 'ERROR: Unable to find player with id') !== false) {
                $responseMessage = ['message' => '该玩家已退出或未存在'];
            } else {
                $responseMessage = ['message' => '已将该玩家封禁'];
            }
        } catch(SourceQueryException $e) {
            $responseMessage = ['error' => 'RCON连接失败: ' . $e->getMessage()];
        } finally {
            $query->Disconnect();
        }
    }
} else {
    $responseMessage = ['message' => '缺少必要的参数'];
}



header('Access-Control-Allow-Origin: https://rcon.przsc.cn');
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header('Content-Type: application/json');
echo json_encode($responseMessage, JSON_UNESCAPED_UNICODE);

?>